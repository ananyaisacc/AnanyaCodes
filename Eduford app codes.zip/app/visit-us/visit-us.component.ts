import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visit-us',
  templateUrl: './visit-us.component.html',
  styleUrls: ['./visit-us.component.css']
})
export class VisitUsComponent implements OnInit {

  public title: string = "At Glance";
  logo = 'assets/eduford_img/logo.png';
  library = 'assets/eduford_img/p10.jpg';
  intermediate =  "assets/eduford_img/Intermediate1.jpg";
  postgraduate = 'assets/eduford_img/postgraduate.jpg';
  degree = 'assets/eduford_img/Degree.jpg';
  innovation = 'assets/eduford_img/project.jfif';
  yoga = 'assets/eduford_img/yoga1.jpg';
  cafeteria = 'assets/eduford_img/cafeteria.png';
  library1 = 'assets/eduford_img/library.png';
  dance = 'assets/eduford_img/DANCE - copy.jpg';
  art = 'assets/eduford_img/art.jpg';
  music = 'assets/eduford_img/Music.jpg';
  tabletennis = 'assets/eduford_img/tabletennis.jpg';
  basketball = 'assets/eduford_img/basketball.png';
  swimming = 'assets/eduford_img/swimming.jpg';

  constructor() { }

  ngOnInit(): void {
  }

}
