import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from 'src/app/home/home.component';
import { VisitUsComponent } from 'src/app/visit-us/visit-us.component';
import { AboutUsComponent } from 'src/app/about-us/about-us.component';
import { RegistrationComponent } from 'src/app/registration/registration.component';
import { LoginComponent } from 'src/app/login/login.component';
import { CourseComponent } from 'src/app/course/course.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'visitUs', component: VisitUsComponent },
  { path: 'about', component: AboutUsComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'login' , component: LoginComponent },
  { path: 'course' , component: CourseComponent },
  { path: '', component: HomeComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
