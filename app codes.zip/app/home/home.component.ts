import { Component, OnInit, ElementRef,ViewChild } from '@angular/core';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 
  logo = 'assets/Cool_Home_Gadgets_Images/logo.png';
  smartDoorLock = 'assets/Cool_Home_Gadgets_Images/bDanalock-V3-Smart-Door-Lock-6.jpg'
  purifier = 'assets/Cool_Home_Gadgets_Images/bDyson-Pure-Hot-Cool-Link-Purifier.jpg'
  thermometer = 'assets/Cool_Home_Gadgets_Images/biGrill-Smart-Food-Thermometer.jpg'
  Knocki = 'assets/Cool_Home_Gadgets_Images/bKnocki-Remote-Control-Smart-Device-5.jpg'
  Momo = 'assets/Cool_Home_Gadgets_Images/bMomo-Smart-Security-Robot.jpg'
  Mopping = 'assets/Cool_Home_Gadgets_Images/bMopping-Robot.jpg'
  Chef = 'assets/Cool_Home_Gadgets_Images/bRobotic-Kitchen-Chef-.jpg'
  Lawnmower = 'assets/Cool_Home_Gadgets_Images/bRobotic-Lawnmower.jpg'
  Sleep = 'assets/Cool_Home_Gadgets_Images/bSleep-Regulating-Alarm-Clock.jpg'
  Shower = 'assets/Cool_Home_Gadgets_Images/bSmart-Digital-Shower-Interface.jpg'
  Espresso = 'assets/Cool_Home_Gadgets_Images/bSmart-Espresso-Machine.jpg'
  Detector = 'assets/Cool_Home_Gadgets_Images/bSmart-Water-Leakage-Detector.jpg'
  t1 = 'assets/Cool_Home_Gadgets_Images/t1.jpg'
  t2 = 'assets/Cool_Home_Gadgets_Images/t2.jpg'
  t3 = 'assets/Cool_Home_Gadgets_Images/t3.jpg'
  t4 = 'assets/Cool_Home_Gadgets_Images/t4.jpg'
  t5 = 'assets/Cool_Home_Gadgets_Images/t5.jpg'
  t6 = 'assets/Cool_Home_Gadgets_Images/t6.jpg'
  t7 = 'assets/Cool_Home_Gadgets_Images/t7.jpg'
  t8 = 'assets/Cool_Home_Gadgets_Images/t8.jpg'
  t9 = 'assets/Cool_Home_Gadgets_Images/t9.jpg'
  t10 = 'assets/Cool_Home_Gadgets_Images/t10.jpg'
  t11 = 'assets/Cool_Home_Gadgets_Images/t11.jpg'
  t12 = 'assets/Cool_Home_Gadgets_Images/t12.jpg'
  h1 = 'assets/Cool_Home_Gadgets_Images/h1.jpg'
  h2 = 'assets/Cool_Home_Gadgets_Images/h2.jpg'
  h3 = 'assets/Cool_Home_Gadgets_Images/h3.jpg'
  h4 = 'assets/Cool_Home_Gadgets_Images/h4.jpg'
  h5 = 'assets/Cool_Home_Gadgets_Images/h5.jpg'
  h6 = 'assets/Cool_Home_Gadgets_Images/h6.jpg'
  h7 = 'assets/Cool_Home_Gadgets_Images/h7.jpg'
  h8 = 'assets/Cool_Home_Gadgets_Images/h8.jpg' 
  
  sa = 'assets/Cool_Home_Gadgets_Images/s1.webp' 
  sb = 'assets/Cool_Home_Gadgets_Images/s2.gif' 
  sc = 'assets/Cool_Home_Gadgets_Images/s3.jpg' 
  sd = 'assets/Cool_Home_Gadgets_Images/s4.jpg' 


  public myCategory:string = '';
 
  constructor() { }

  ngOnInit(): void {
  }   
  
  
}
