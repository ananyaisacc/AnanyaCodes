import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image-gallery',
  templateUrl: './image-gallery.component.html',
  styleUrls: ['./image-gallery.component.css']
})
export class ImageGalleryComponent implements OnInit {
  h = 'assets/Cool_Home_Gadgets_Images/h2.gif';
  value = ''
  constructor() { }

  ngOnInit(): void {
  }

  
}
