export class products  {
    id:number= 0;
    name:string = '';
    price:number = 0;
}