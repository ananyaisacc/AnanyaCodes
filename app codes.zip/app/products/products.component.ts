import { Component, OnInit } from '@angular/core';
import { products } from 'src/app/products/product';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  
  logo = 'assets/Cool_Home_Gadgets_Images/logo.png';
  smartDoorLock = 'assets/Cool_Home_Gadgets_Images/bDanalock-V3-Smart-Door-Lock-6.jpg'
  purifier = 'assets/Cool_Home_Gadgets_Images/bDyson-Pure-Hot-Cool-Link-Purifier.jpg'
  thermometer = 'assets/Cool_Home_Gadgets_Images/biGrill-Smart-Food-Thermometer.jpg'
  Knocki = 'assets/Cool_Home_Gadgets_Images/bKnocki-Remote-Control-Smart-Device-5.jpg'
  Momo = 'assets/Cool_Home_Gadgets_Images/bMomo-Smart-Security-Robot.jpg'
  Mopping = 'assets/Cool_Home_Gadgets_Images/bMopping-Robot.jpg'
  Chef = 'assets/Cool_Home_Gadgets_Images/bRobotic-Kitchen-Chef-.jpg'
  Lawnmower = 'assets/Cool_Home_Gadgets_Images/bRobotic-Lawnmower.jpg'
  Sleep = 'assets/Cool_Home_Gadgets_Images/bSleep-Regulating-Alarm-Clock.jpg'
  Shower = 'assets/Cool_Home_Gadgets_Images/bSmart-Digital-Shower-Interface.jpg'
  Espresso = 'assets/Cool_Home_Gadgets_Images/bSmart-Espresso-Machine.jpg'
  Detector = 'assets/Cool_Home_Gadgets_Images/bSmart-Water-Leakage-Detector.jpg'
  t1 = 'assets/Cool_Home_Gadgets_Images/t1.jpg'
  t2 = 'assets/Cool_Home_Gadgets_Images/t2.jpg'
  t3 = 'assets/Cool_Home_Gadgets_Images/t3.jpg'
  t4 = 'assets/Cool_Home_Gadgets_Images/t4.jpg'
  t5 = 'assets/Cool_Home_Gadgets_Images/t5.jpg'
  t6 = 'assets/Cool_Home_Gadgets_Images/t6.jpg'
  t7 = 'assets/Cool_Home_Gadgets_Images/t7.jpg'
  t8 = 'assets/Cool_Home_Gadgets_Images/t8.jpg'
  t9 = 'assets/Cool_Home_Gadgets_Images/t9.jpg'
  t10 = 'assets/Cool_Home_Gadgets_Images/t10.jpg'
  t11 = 'assets/Cool_Home_Gadgets_Images/t11.jpg'
  t12 = 'assets/Cool_Home_Gadgets_Images/t12.jpg'
  h1 = 'assets/Cool_Home_Gadgets_Images/h1.jpg'
  h2 = 'assets/Cool_Home_Gadgets_Images/h2.jpg'
  h3 = 'assets/Cool_Home_Gadgets_Images/h3.jpg'
  h4 = 'assets/Cool_Home_Gadgets_Images/h4.jpg'
  h5 = 'assets/Cool_Home_Gadgets_Images/h5.jpg'
  h6 = 'assets/Cool_Home_Gadgets_Images/h6.jpg'
  h7 = 'assets/Cool_Home_Gadgets_Images/h7.jpg'
  h8 = 'assets/Cool_Home_Gadgets_Images/h8.jpg' 
  h9 = 'assets/Cool_Home_Gadgets_Images/h9.jpg' 



  product:products[] = [
    {id:0, name:'Bunker Beds with Sofa', price: 8599 },
    {id:1, name:'Smart Desk with Movable Draw', price: 4300 },
    {id:2, name:'Smart way of storing your Cutlery', price: 3000 },
    {id:3, name:'Amazing Sofa Set', price: 10999 },
    {id:4, name:'Bed with Closet', price: 9899 },
    {id:5, name:'Storable Staircase', price: 4000 },
    {id:6, name:'Amazing Chef Knives', price: 100 },
    {id:7, name:'Multipurpose Cabinet', price: 5989 },
    {id:8, name:'The Grip Jar Opener', price: 400 },
    {id:9, name:'Cordy Robot Vacuum Cleaner', price: 2500 },
    {id:10, name:'Dash Rapid Egg Cooker', price: 800 },
    {id:11, name:'Hand Blender Set', price: 350 },
    {id:12, name:'Portable Printer', price: 2600 },
    {id:13, name:'Charging Hub', price: 2100 },
    {id:14, name:' Breakfast Maker', price: 2599 },
    {id:15, name:'Pineapple Peeler', price: 400 },
    {id:16, name: 'Espresso Machine', price:699 },
    {id:17, name: 'Sleep Alarm Clock', price:700 },
    {id:18, name: 'Water Leakage Detector', price:2589 },
    {id:19, name: 'Robotic Lawn Mower', price:1500 },
    {id:20, name: 'Knocki', price:2475 },
    {id:21, name: 'Momo Smart Security Robot', price:1200 },
    {id:22, name: 'Robot Floor Mop', price:940 },
    {id:23, name: 'Dyson Purifier', price:4179 },
  ]



  myCart:products[] = [

  ];

  


  constructor() { }

  ngOnInit(): void {
  }

  add(prod:products) {
   
    this.myCart.push(prod);
    console.log(this.myCart)
    alert('Added to cart successfully!')
    
  }
  fav(prod:products){
    alert('Hello')
  }

  sum = 0;
  total(){
    
    for(let i=0; i<this.myCart.length; i++) {
      this.sum += this.myCart[i].price;
    }
    console.log(this.sum)
  }
  

  dis =0
  tot =0
  discount(){
    this.dis = Math.trunc(this.sum*0.2)
    this.tot = this.sum - this.dis
  }
}
