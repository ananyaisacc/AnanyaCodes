import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent implements OnInit {


  h1 = 'assets/Cool_Home_Gadgets_Images/h1.jpg'
  h2 = 'assets/Cool_Home_Gadgets_Images/h2.jpg'
  h3 = 'assets/Cool_Home_Gadgets_Images/h3.jpg'
  h4 = 'assets/Cool_Home_Gadgets_Images/h4.jpg'
  h5 = 'assets/Cool_Home_Gadgets_Images/h5.jpg'
  h6 = 'assets/Cool_Home_Gadgets_Images/h6.jpg'
  constructor() { }

  ngOnInit(): void {
  }

}
